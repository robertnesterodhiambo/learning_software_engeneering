/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arduino;

/**
 *
 * @author dragon
 */
public class Arduino {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
